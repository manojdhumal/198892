export const environment = {
  production: true,
  apiUrl: '/smartApp/api/User-reg-mgmt/v1/'
};
