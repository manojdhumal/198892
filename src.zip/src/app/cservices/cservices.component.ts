import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cservices',
  templateUrl: './cservices.component.html',
  styleUrls: ['./cservices.component.css']
})
export class CservicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
